<div class="flex flex-col items-center justify-center gap-4 rounded-3xl border border-dashed border-white/20 bg-[#041734]/60 p-12 text-center shadow-[0_26px_60px_-28px_rgba(5,23,63,0.8)]">
    <span class="text-3xl font-semibold text-amber-300" aria-hidden="true">N/A</span>
    <h3 class="text-xl font-semibold text-white">Belum ada artikel</h3>
    <p class="max-w-md text-sm text-slate-300">
        Konten blog akan segera tersedia. Sementara itu, pantau halaman agenda untuk informasi terbaru seputar aktivitas Waduk Manduk.
    </p>
</div>
